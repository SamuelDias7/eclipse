package com.uml;

public class Pessoa {
	// Atributos
	private int idPessoa;
	private  String nome;
	private String email;
	private String profissao;
	private double altura;
	private double peso;

	public Pessoa(int idPessoa) {
		// TODO Auto-generated constructor stub
	}
	public double calcularImc() {
		return 0;
	}
	public String exibirDiagnostico(double imc) {
		return null;
	}

}
